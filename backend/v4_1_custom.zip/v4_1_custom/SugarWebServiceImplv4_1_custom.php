<?php
require_once('service/v4_1/SugarWebServiceImplv4_1.php');

class SugarWebServiceImplv4_1_custom extends SugarWebServiceImplv4_1 {

    public function get_question_bank() {
    global $db;
    $user_id = $_REQUEST['user_id'];

    // Pehle training_progress ke sath join kar ke check karo ke user ke related records hain ya nahi
    $query = "SELECT
                question_bank.id AS question_bank_id,
                question_bank.step_number,
                question_bank.title,
                question_bank.link,
                training_progress.is_completed
              FROM question_bank
              LEFT JOIN training_progress
                ON question_bank.id = training_progress.question_id
                AND training_progress.user_id = '{$db->quote($user_id)}'";

    $result = $db->query($query);

    $questions = [];
    $hasTrainingProgress = false;

    while ($row = $db->fetchByAssoc($result)) {
        // Agar training_progress me is_completed value milti hai to samajh lo user ke related record hai
        if (!empty($row['is_completed'])) {
            $hasTrainingProgress = true;
        }

        $questions[] = [
            'id'          => $row['question_bank_id'],
            'step_number' => $row['step_number'],
            'title'       => $row['title'],
            'is_completed'=> !empty($row['is_completed']) ? $row['is_completed'] : false,
            'link'        => $row['link']
        ];
    }

    // Agar training_progress me koi data na mila, to sirf question_bank table ka data fetch karo
    if (!$hasTrainingProgress) {
        $queryOnlyQuestionBank = "SELECT
                                    id AS question_bank_id,
                                    step_number,
                                    title,
                                    link
                                  FROM question_bank";
        $result = $db->query($queryOnlyQuestionBank);

        $questions = [];
        while ($row = $db->fetchByAssoc($result)) {
            $questions[] = [
                'id'          => $row['question_bank_id'],
                'step_number' => $row['step_number'],
                'title'       => $row['title'],
                'is_completed'=> false,
                'link'        => $row['link']
            ];
        }
    }

    return [
        'status' => 'success',
        'data'   => $questions
    ];
}


    public function training_process_entry($session) {
        global $db;
        $question_id = $_REQUEST['question_id'];
        $user_id = $_REQUEST['user_id'];
        $is_completed = $_REQUEST['is_completed'];

        // Check if record already exists
        $query = "SELECT id FROM training_progress
                WHERE question_id = '{$db->quote($question_id)}'
                AND user_id = '{$db->quote($user_id)}'
                LIMIT 1";
                $result = $db->query($query);
                // print_r();die();
                $row = $db->fetchByAssoc($result);
                if ($result->num_rows) {
                    // Update if exists
                    $update = "UPDATE training_progress
                            SET is_completed = '{$db->quote($is_completed)}', completed_at = NOW()
                            WHERE id = '{$row['id']}'";
                    $db->query($update);
                } else {
                    // Insert new record
                    $id = create_guid();
                    // print_r($id);die();
                    $insert = "INSERT INTO training_progress (id, question_id, user_id, is_completed, completed_at) VALUES ('{$id}', '{$db->quote($question_id)}', '{$db->quote($user_id)}', '{$db->quote($is_completed)}', NOW())";
                    $db->query($insert);
                }
    }
   public function get_user_data() {
        global $db;

        // Get values from request
        $user_id = isset($_REQUEST['user_id']) ? $_REQUEST['user_id'] : '';
        $current_step = isset($_REQUEST['current_step']) ? $_REQUEST['current_step'] : '';

        if (empty($current_step)) {
             $userData = $this->fetchUserData($user_id);
            if (!$userData) {
                return [
                    'status' => 'error',
                    'message' => 'User not found'
                ];
            }
            return [
                'status' => 'success',
                'message' => 'User data fetched successfully',
                'data' => $userData
            ];
        }
        if (empty($user_id) ) {
            return [
                'status' => 'error',
                'message' => 'User ID and current_step are required'
            ];
        }

        // Step 1: Get current user role value
        $query = "SELECT user_role_c FROM users WHERE id = '" . $db->quote($user_id) . "' LIMIT 1";
        $result = $db->query($query);
        $row = $db->fetchByAssoc($result);

        $user_role = isset($row['user_role_c']) ? $row['user_role_c'] : null;

        // Step 2: Check conditions
        if ($user_role !== null && $user_role >= $current_step) {
            if($user_role=='8'){

                // $response=$this->Send_Email_On_Finish();
                // return $response;
            }
            return [
                'status' => 'no_update',
                'message' => 'No update required, user_role is already set or greater.',
                'current_role' => $user_role
            ];
        }

        // Step 3: Update user_role_c with new current_step
        $updateQuery = "
            UPDATE users
            SET user_role_c = '" . $db->quote($current_step) . "'
            WHERE id = '" . $db->quote($user_id) . "'
        ";
        $db->query($updateQuery);

        return [
            'status' => 'success',
            'message' => 'User role updated successfully.',
            'updated_role' => $current_step
        ];
    }

    /**
     * Fetch user data by ID
     */
    private function fetchUserData($user_id) {
        global $db;
        $query = "
            SELECT id, user_name as name, first_name, last_name
            FROM users
            WHERE id = '" . $db->quote($user_id) . "'
            LIMIT 1
        ";
        $result = $db->query($query);
        return $db->fetchByAssoc($result);
    }
    public function send_Email($session, $data)
    {
        global $db;
        $user_id = isset($_REQUEST['user_id']) ? $_REQUEST['user_id'] : '';

        require_once "include/SugarPHPMailer.php";
        $user_id = isset($_REQUEST['user_id']) ? $_REQUEST['user_id'] : '';
        try {
            $mailer = new SugarPHPMailer();
            $admin = new Administration();
            $admin->retrieveSettings();
            $mailer->prepForOutbound();
            $mailer->setMailerForSystem();
            // pre($admin);
            $mailer->From = $admin->settings['notify_fromaddress'];
            $mailer->FromName = 'zeeshanirfan913@gmail.com';
            $mailer->IsHTML(true);
            $mailer->Subject = 'My Email Notification! ';
            $mailer->Body = ' fired for bean ';
            $mailer->AddAddress('zeeshanirfan913@gmail.com');

            if($mailer->send()){
                $query = "
                INSERT INTO acl_roles_users (id, role_id, user_id, date_modified, deleted)
                SELECT UUID(), r.id, '$user_id', NOW(), 0
                FROM acl_roles r
                WHERE r.name = 'test'
                AND NOT EXISTS (
                    SELECT 1
                    FROM acl_roles_users aru
                    WHERE aru.role_id = r.id
                    AND aru.user_id = '$user_id'
                    AND aru.deleted = 0
                )
                ";

                // Execute query
                $db->query($query);
                return array(
                'status' => 'success',
                'message' => 'Email sent successfully!',
                'data_received' => $data
            );
            }
        } catch (Exception $e) {
        echo 'Caught exception: ',  $e->getMessage(), "\n";
        }


    }
    public function modify_user_basic_details()
    {
        // 🔹 User ID نکالیں
        $user_id = $_REQUEST['user_id'] ?? null;

        // 🔹 Parameter JSON decode کریں
        $parameter_json = html_entity_decode($_REQUEST['parameter']); // &quot; کو صاف کرنے کیلئے
        $parameter = json_decode($parameter_json, true);

        if (!$user_id || empty($parameter)) {
            echo json_encode(['success' => false, 'message' => 'Invalid request data']);
            return;
        }

        // 🔹 Bean لوڈ کریں
        $bean = BeanFactory::getBean('Users', $user_id);
        if (!$bean) {
            echo json_encode(['success' => false, 'message' => 'User not found']);
            return;
        }

        // 🔹 Parameter کی keys کو bean میں save کریں
        foreach ($parameter as $key => $value) {
            if (property_exists($bean, $key)) {
                $bean->$key = $value;
            }
        }

        // 🔹 Save bean
        $bean->save();

        // 🔹 Response واپس کریں
        return array(
            'success' => true,
            'message' => 'User details updated successfully',
            'updated_fields' => $parameter
        );
    }
public function change_user_password()
{
    global $db;

    $user_id = $_REQUEST['user_id'] ?? '';
    $current_password = $_REQUEST['current_password'] ?? '';
    $new_password = $_REQUEST['new_password'] ?? '';

    if (empty($user_id) || empty($current_password) || empty($new_password)) {
        return array(
            'error' => true,
            'message' => 'Missing required fields'
        );
    }

    // Load user bean
    $user = BeanFactory::getBean('Users', $user_id);

    if (!$user || empty($user->id)) {
        return array(
            'error' => true,
            'message' => 'User not found'
        );
    }
    // Verify current password
    if ($user->checkPassword($current_password, $user->user_hash)) {

        $user->change_password($current_password, $new_password);
        return array(
            'success' => true,
            'message' => 'Password changed successfully'
        );
    } else {
        return array(
            'error' => true,
            'message' => 'Current password is incorrect'
        );
    }
}

}
