<?php
$registry['custom']['get_question_bank'] = [
    'file' => 'service/v4_1_custom/SugarWebServiceImplv4_1_custom.php',
    'class' => 'SugarWebServiceImplv4_1_custom',
    'method' => 'get_question_bank'
];
$registry['custom']['training_process_entry'] = [
    'file' => 'service/v4_1_custom/SugarWebServiceImplv4_1_custom.php',
    'class' => 'SugarWebServiceImplv4_1_custom',
    'method' => 'training_process_entry'
];
$registry['custom']['get_user_data'] = [
    'file' => 'service/v4_1_custom/SugarWebServiceImplv4_1_custom.php',
    'class' => 'SugarWebServiceImplv4_1_custom',
    'method' => 'get_user_data'
];
$registry['custom']['login'] = [
    'file' => 'service/v4_1_custom/SugarWebServiceImplv4_1_custom.php',
    'class' => 'SugarWebServiceImplv4_1_custom',
    'method' => 'login'
];
$registry['custom']['send_Email'] = [
    'file' => 'service/v4_1_custom/SugarWebServiceImplv4_1_custom.php',
    'class' => 'SugarWebServiceImplv4_1_custom',
    'method' => 'send_Email'
];
$registry['custom']['modify_user_basic_details'] = [
    'file' => 'service/v4_1_custom/SugarWebServiceImplv4_1_custom.php',
    'class' => 'SugarWebServiceImplv4_1_custom',
    'method' => 'modify_user_basic_details'
];