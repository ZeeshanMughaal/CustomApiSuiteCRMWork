<?php
class QuestionBankApi {
    function getQuestionBank($session, $args) {
        return array(
            "success" => true,
            "message" => "Custom API working via rest.php",
            "data" => $args
        );
    }
}
